var classfr_1_1iessa_1_1dao_1_1trafic_1_1_trafic_dao =
[
    [ "charger", "classfr_1_1iessa_1_1dao_1_1trafic_1_1_trafic_dao.html#a20764afd2e1ff58637ec375f5dbd203b", null ],
    [ "chargerVol", "classfr_1_1iessa_1_1dao_1_1trafic_1_1_trafic_dao.html#ac1705acef8800dccc21ca6ae83c0182f", null ]
];