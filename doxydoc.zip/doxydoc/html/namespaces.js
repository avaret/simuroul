var namespaces =
[
    [ "fr", "namespacefr.html", "namespacefr" ]
];