var classfr_1_1iessa_1_1vue_1_1trafic_1_1_panel_trafic_1_1_work_done_observable =
[
    [ "setChanged", "classfr_1_1iessa_1_1vue_1_1trafic_1_1_panel_trafic_1_1_work_done_observable.html#a398ce68818b87cd5e933c68b02fe6ba4", null ]
];